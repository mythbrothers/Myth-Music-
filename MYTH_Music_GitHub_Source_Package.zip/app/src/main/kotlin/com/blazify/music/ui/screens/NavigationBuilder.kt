/**
 * Blazify Project (C) 2026
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See NOTICE for contributors
 */

package com.blazify.music.ui.screens

import android.app.Activity
import androidx.compose.foundation.layout.RowScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.compose.dialog
import androidx.navigation.navArgument
import com.blazify.music.constants.DarkModeKey
import com.blazify.music.constants.PureBlackKey
import com.blazify.music.ui.screens.artist.ArtistAlbumsScreen
import com.blazify.music.ui.screens.artist.ArtistItemsScreen
import com.blazify.music.ui.screens.artist.ArtistScreen
import com.blazify.music.ui.screens.artist.ArtistSongsScreen
import com.blazify.music.ui.screens.equalizer.EqScreen
import com.blazify.music.ui.screens.equalizer.wizard.WizardScreen
import com.blazify.music.R
import com.blazify.music.ui.screens.library.LibraryAlbumsScreen
import com.blazify.music.ui.screens.library.LibraryArtistsScreen
import com.blazify.music.ui.screens.library.LibraryScreen
import com.blazify.music.ui.screens.library.LibrarySongsScreen
import com.blazify.music.ui.screens.library.LocalFoldersScreen
import com.blazify.music.ui.screens.playlist.AutoPlaylistScreen
import com.blazify.music.ui.screens.playlist.CachePlaylistScreen
import com.blazify.music.ui.screens.playlist.LocalPlaylistScreen
import com.blazify.music.ui.screens.playlist.OnlinePlaylistScreen
import com.blazify.music.ui.screens.playlist.TopPlaylistScreen
import com.blazify.music.ui.screens.podcast.OnlinePodcastScreen
import com.blazify.music.ui.screens.recognition.RecognitionHistoryScreen
import com.blazify.music.ui.screens.recognition.RecognitionScreen
import com.blazify.music.ui.screens.search.OnlineSearchResult
import com.blazify.music.ui.screens.search.SearchScreen
import com.blazify.music.ui.screens.settings.AboutScreen
import com.blazify.music.ui.screens.settings.AiSettings
import com.blazify.music.ui.screens.settings.LyricsSettings
import com.blazify.music.ui.screens.settings.AndroidAutoSettings
import com.blazify.music.ui.screens.settings.AppearanceSettings
import com.blazify.music.ui.screens.settings.LookAndFeelScreen
import com.blazify.music.ui.screens.settings.BackupAndRestore
import com.blazify.music.ui.screens.settings.ContentSettings
import com.blazify.music.ui.screens.settings.DarkMode
import com.blazify.music.ui.screens.settings.PlayerSettings
import com.blazify.music.ui.screens.settings.PrivacySettings
import com.blazify.music.ui.screens.settings.BlockedArtistsSettings
import com.blazify.music.ui.screens.settings.HiddenSongsSettings
import com.blazify.music.ui.screens.settings.RomanizationSettings
import com.blazify.music.ui.screens.settings.SettingsScreen
import com.blazify.music.ui.screens.settings.StorageSettings
import com.blazify.music.ui.component.SpotifyImportDialog
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import com.blazify.music.ui.screens.settings.integrations.ListenBrainzSettings
import com.blazify.music.ui.screens.settings.PlayerDesignScreen
import com.blazify.music.ui.screens.settings.UpdaterScreen
import com.blazify.music.ui.screens.settings.integrations.DiscordSettings
import com.blazify.music.ui.screens.settings.integrations.IntegrationScreen
import com.blazify.music.ui.screens.settings.integrations.LastFMSettings
import com.blazify.music.ui.screens.settings.integrations.ListenTogetherSettings

import com.blazify.music.ui.screens.wrapped.WrappedScreen
import com.blazify.music.utils.rememberEnumPreference
import com.blazify.music.utils.rememberPreference

@OptIn(ExperimentalMaterial3Api::class)
fun NavGraphBuilder.navigationBuilder(
    navController: NavHostController,
    scrollBehavior: TopAppBarScrollBehavior,
    latestVersionName: String,
    activity: Activity,
    snackbarHostState: SnackbarHostState,
) {
    composable(Screens.Home.route) {
        HomeScreen(snackbarHostState = snackbarHostState)
    }

    composable(Screens.Search.route) { backStackEntry ->
        val pureBlackEnabled by rememberPreference(PureBlackKey, defaultValue = true)
        val darkTheme by rememberEnumPreference(DarkModeKey, defaultValue = DarkMode.AUTO)
        val isSystemInDarkTheme = isSystemInDarkTheme()
        val useDarkTheme =
            remember(darkTheme, isSystemInDarkTheme) {
                if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
            }
        val pureBlack =
            remember(pureBlackEnabled, useDarkTheme) {
                pureBlackEnabled && useDarkTheme
            }
        SearchScreen(
            pureBlack = pureBlack,
            savedStateHandle = backStackEntry.savedStateHandle
        )
    }

    composable(Screens.Library.route) {
        LibraryScreen()
    }

    composable(Screens.Yours.route) {
        YoursScreen()
    }

    composable("yours/playlists") {
        var showSpotifyImport by rememberSaveable { mutableStateOf(false) }
        if (showSpotifyImport) {
            SpotifyImportDialog(
                onDismiss = { showSpotifyImport = false },
                onImported = { playlistId ->
                    showSpotifyImport = false
                    navController.navigate("local_playlist/$playlistId")
                },
            )
        }
        YoursCategoryScreen(
            navController,
            R.string.playlists,
            actions = {
                TextButton(
                    onClick = { showSpotifyImport = true },
                    shape = CircleShape,
                    colors =
                        ButtonDefaults.textButtonColors(
                            containerColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f),
                        ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp).padding(end = 4.dp),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.spotify),
                        contentDescription = null,
                        tint = Color.Unspecified,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.import_spotify),
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            },
        ) {
            YoursPlaylistsGrid(navController)
        }
    }
    composable("yours/songs") {
        YoursCategoryScreen(navController, R.string.songs) {
            LibrarySongsScreen(navController, onDeselect = {})
        }
    }
    composable("yours/albums") {
        YoursCategoryScreen(navController, R.string.albums) {
            LibraryAlbumsScreen(navController, onDeselect = {})
        }
    }
    composable("yours/artists") {
        YoursCategoryScreen(navController, R.string.artists) {
            LibraryArtistsScreen(navController, onDeselect = {})
        }
    }

    composable(Screens.ListenTogether.route) {
        ListenTogetherScreen(navController, showTopBar = false)
    }

    composable(
        route = "listen_together_from_topbar",
    ) {
        ListenTogetherScreen(navController, showTopBar = true)
    }

    composable("history") {
        HistoryScreen(navController)
    }

    composable("stats") {
        StatsScreen(navController)
    }

    composable("mood_and_genres") {
        MoodAndGenresScreen(navController)
    }

    composable("account") {
        AccountScreen(navController)
    }

    composable("new_release") {
        NewReleaseScreen(navController)
    }

    composable("charts_screen") {
        ChartsScreen(navController)
    }

    composable(
        route = "browse/{browseId}",
        arguments =
            listOf(
                navArgument("browseId") {
                    type = NavType.StringType
                },
            ),
    ) {
        BrowseScreen(
            navController,
            it.arguments?.getString("browseId"),
        )
    }

    composable(
        route = "search/{query}",
        arguments =
            listOf(
                navArgument("query") {
                    type = NavType.StringType
                },
            ),
        enterTransition = {
            fadeIn(tween(250))
        },
        exitTransition = {
            if (targetState.destination.route?.startsWith("search/") == true) {
                fadeOut(tween(200))
            } else {
                fadeOut(tween(200)) + slideOutHorizontally { -it / 2 }
            }
        },
        popEnterTransition = {
            if (initialState.destination.route?.startsWith("search/") == true) {
                fadeIn(tween(250))
            } else {
                fadeIn(tween(250)) + slideInHorizontally { -it / 2 }
            }
        },
        popExitTransition = {
            fadeOut(tween(200))
        },
    ) { backStackEntry ->
        OnlineSearchResult(
            savedStateHandle = backStackEntry.savedStateHandle
        )

    }

    composable(
        route = "album/{albumId}",
        arguments =
            listOf(
                navArgument("albumId") {
                    type = NavType.StringType
                },
            ),
    ) {
        AlbumScreen(navController)
    }

    composable(
        route = "artist/{artistId}?isPodcastChannel={isPodcastChannel}",
        arguments =
            listOf(
                navArgument("artistId") {
                    type = NavType.StringType
                },
                navArgument("isPodcastChannel") {
                    type = NavType.BoolType
                    defaultValue = false
                },
            ),
    ) {
        ArtistScreen(navController)
    }

    composable(
        route = "artist/{artistId}/songs",
        arguments =
            listOf(
                navArgument("artistId") {
                    type = NavType.StringType
                },
            ),
    ) {
        ArtistSongsScreen(navController)
    }

    composable(
        route = "artist/{artistId}/albums",
        arguments =
            listOf(
                navArgument("artistId") {
                    type = NavType.StringType
                },
            ),
    ) {
        ArtistAlbumsScreen(navController, scrollBehavior)
    }

    composable(
        route = "artist/{artistId}/items?browseId={browseId}?params={params}",
        arguments =
            listOf(
                navArgument("artistId") {
                    type = NavType.StringType
                },
                navArgument("browseId") {
                    type = NavType.StringType
                    nullable = true
                },
                navArgument("params") {
                    type = NavType.StringType
                    nullable = true
                },
            ),
    ) {
        ArtistItemsScreen(navController)
    }

    composable(
        route = "online_playlist/{playlistId}",
        arguments =
            listOf(
                navArgument("playlistId") {
                    type = NavType.StringType
                },
            ),
    ) {
        OnlinePlaylistScreen(navController)
    }

    composable(
        route = "online_podcast/{podcastId}",
        arguments =
            listOf(
                navArgument("podcastId") {
                    type = NavType.StringType
                },
            ),
    ) {
        OnlinePodcastScreen(navController, scrollBehavior)
    }

    composable(
        route = "local_playlist/{playlistId}",
        arguments =
            listOf(
                navArgument("playlistId") {
                    type = NavType.StringType
                },
            ),
    ) {
        LocalPlaylistScreen(navController)
    }

    composable(
        route = "auto_playlist/{playlist}?folder={folder}",
        arguments =
            listOf(
                navArgument("playlist") {
                    type = NavType.StringType
                },
                navArgument("folder") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
            ),
    ) {
        AutoPlaylistScreen(navController)
    }

    composable("local_folders") {
        LocalFoldersScreen(navController)
    }

    composable(
        route = "cache_playlist/{playlist}",
        arguments =
            listOf(
                navArgument("playlist") {
                    type = NavType.StringType
                },
            ),
    ) {
        CachePlaylistScreen(navController)
    }

    composable(
        route = "top_playlist/{top}",
        arguments =
            listOf(
                navArgument("top") {
                    type = NavType.StringType
                },
            ),
    ) {
        TopPlaylistScreen(navController)
    }

    composable(
        // A mood tile passes its name along: that is how the page finds the
        // Home chip of the same mood, whose shelves are made for the account.
        route = "youtube_browse/{browseId}?params={params}&title={title}",
        arguments =
            listOf(
                navArgument("browseId") {
                    type = NavType.StringType
                    nullable = true
                },
                navArgument("params") {
                    type = NavType.StringType
                    nullable = true
                },
                navArgument("title") {
                    type = NavType.StringType
                    nullable = true
                },
            ),
    ) {
        YouTubeBrowseScreen(navController)
    }

    composable("settings") {
        SettingsScreen(navController, latestVersionName)
    }

    composable("settings/appearance") {
        AppearanceSettings(navController, activity, snackbarHostState)
    }

    composable("settings/appearance/look_and_feel") {
        LookAndFeelScreen(navController)
    }

    composable("settings/appearance/player_design") {
        PlayerDesignScreen(navController)
    }

    composable("settings/content") {
        ContentSettings(navController)
    }

    composable("settings/content/romanization") {
        RomanizationSettings(navController)
    }

    composable("settings/content/hidden_songs") {
        HiddenSongsSettings(navController)
    }

    composable("settings/content/blocked_artists") {
        BlockedArtistsSettings(navController)
    }

    composable("settings/ai") {
        AiSettings(navController)
    }

    composable("settings/lyrics") {
        LyricsSettings(navController)
    }

    composable("settings/player") {
        PlayerSettings(navController)
    }

    composable("settings/storage") {
        StorageSettings(navController)
    }

    composable("settings/privacy") {
        PrivacySettings(navController)
    }

    composable("settings/backup_restore") {
        BackupAndRestore(navController)
    }

    composable("settings/integrations") {
        IntegrationScreen(navController)
    }

    composable("settings/integrations/discord") {
        DiscordSettings(navController)
    }

    composable("settings/integrations/lastfm") {
        LastFMSettings(navController)
    }
    composable("settings/integrations/listenbrainz") {
        ListenBrainzSettings(navController)
    }

    composable(route = "settings/integrations/listen_together") {
        ListenTogetherSettings(navController)
    }

    composable("settings/updater") {
        UpdaterScreen(navController)
    }

    composable("settings/about") {
        AboutScreen(navController)
    }

    composable("login") {
        LoginScreen(navController)
    }

    composable("wrapped") {
        WrappedScreen()
    }

    composable("equalizer") {
        EqScreen()
    }

    composable("eq_wizard") {
        WizardScreen(onNavigateBack = {
            navController.popBackStack()
        })
    }

    composable(
        route = "recognition?autoStart={autoStart}",
        arguments =
            listOf(
                navArgument("autoStart") {
                    type = NavType.BoolType
                    defaultValue = false
                },
            ),
    ) {
        RecognitionScreen(navController, it.arguments?.getBoolean("autoStart") ?: false)
    }

    composable("recognition_history") {
        RecognitionHistoryScreen(navController)
    }
    composable("settings/android_auto") {
        AndroidAutoSettings(navController, scrollBehavior)
    }
}
