/**
 * Blazify Project (C) 2026
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See NOTICE for contributors
 */

package com.blazify.music.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.blazify.innertube.YouTube
import com.blazify.innertube.models.AlbumItem
import com.blazify.innertube.models.ArtistItem
import com.blazify.innertube.models.PlaylistItem
import com.blazify.innertube.models.SongItem
import com.blazify.innertube.models.WatchEndpoint
import com.blazify.innertube.models.YTItem
import com.blazify.innertube.models.filterExplicit
import com.blazify.innertube.models.filterVideoSongs
import com.blazify.innertube.pages.MoodAndGenres
import com.blazify.innertube.utils.YouTubeUrlParser
import com.blazify.music.constants.HideExplicitKey
import com.blazify.music.constants.HideVideoSongsKey
import com.blazify.music.db.MusicDatabase
import com.blazify.music.db.entities.SearchHistory
import com.blazify.music.utils.dataStore
import com.blazify.music.utils.get
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.coroutineScope
import com.blazify.music.utils.BrowseArt
import com.blazify.music.utils.GenreTaste
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
/** How many moods Search > Browse shows. */
const val BROWSE_MOODS = 12

/** The fewest genres Search > Browse shows, for a listener with no history yet. */
const val BROWSE_GENRES_MIN = 6

@HiltViewModel
class OnlineSearchSuggestionViewModel
    @Inject
    constructor(
        @ApplicationContext val context: Context,
        private val database: MusicDatabase,
    ) : ViewModel() {
        val query = MutableStateFlow("")
        private val _viewState = MutableStateFlow(SearchSuggestionViewState())
        val viewState = _viewState.asStateFlow()

        /**
         * Moods and genres for the idle screen, so an empty search box offers
         * something to browse rather than a blank page. Fetched once — the
         * list barely changes and a failure just leaves the section out.
         */
        val moods = MutableStateFlow<List<MoodAndGenres.Item>>(emptyList())

        /** The covers for each Browse tile, by [BrowseArt] key; tiles without any show just their colour. */
        val browseArt = MutableStateFlow<Map<String, List<String>>>(emptyMap())

        /** Which of [moods] are genres, and how each scores for this listener. See [GenreTaste]. */
        val genreScores = GenreTaste.scores
        val genreTitles = GenreTaste.genreTitles

        init {
            viewModelScope.launch {
                YouTube.moodAndGenres().onSuccess { sections ->
                    // The same mood appears under more than one section — "Commute"
                    // sits in both moods and activities — and a grid with it in
                    // twice looks like a bug.
                    moods.value = sections.flatMap { it.items }.distinctBy { it.title }
                    // The listener's genres first, learned from their history; the
                    // tiles shown get their covers, and a few more are read for the
                    // taste at the same time.
                    GenreTaste.refresh(context, database, sections)
                    loadBrowseArt(shownOnBrowse())
                }
            }

            viewModelScope.launch {
                query
                    .flatMapLatest { query ->
                        if (query.isEmpty()) {
                            database.searchHistory().map { history ->
                                SearchSuggestionViewState(
                                    history = history,
                                )
                            }
                        } else {
                            // Check if query is a YouTube URL
                            val parsedUrl = YouTubeUrlParser.parse(query)
                            if (parsedUrl != null) {
                                // Fetch content from YouTube URL
                                val parsedItem = fetchParsedUrlItem(parsedUrl)
                                database
                                    .searchHistory(query)
                                    .map { it.take(3) }
                                    .map { history ->
                                        SearchSuggestionViewState(
                                            history = history,
                                            suggestions = emptyList(),
                                            items = parsedItem?.let { listOf(it) } ?: emptyList(),
                                            parsedUrlItem = parsedItem,
                                            isUrlQuery = true,
                                        )
                                    }
                            } else {
                                val result = YouTube.searchSuggestions(query).getOrNull()
                                val hideExplicit = context.dataStore.get(HideExplicitKey, false)
                                val hideVideoSongs = context.dataStore.get(HideVideoSongsKey, false)

                                database
                                    .searchHistory(query)
                                    .map { it.take(3) }
                                    .map { history ->
                                        SearchSuggestionViewState(
                                            history = history,
                                            suggestions =
                                                result
                                                    ?.queries
                                                    ?.filter { suggestionQuery ->
                                                        history.none { it.query == suggestionQuery }
                                                    }.orEmpty(),
                                            items =
                                                result
                                                    ?.recommendedItems
                                                    ?.distinctBy { it.id }
                                                    ?.filterExplicit(hideExplicit)
                                                    ?.filterVideoSongs(hideVideoSongs)
                                                    .orEmpty(),
                                        )
                                    }
                            }
                        }
                    }.collect {
                        _viewState.value = it
                    }
            }
        }

        /** The tiles Browse shows: the moods, then the listener's genres and a couple more. */
        fun shownOnBrowse(): List<MoodAndGenres.Item> {
            val ordered = GenreTaste.order(moods.value) { it.title }
            val genres = ordered.filter { GenreTaste.isGenre(it.title) }
            val shownGenres = maxOf(BROWSE_GENRES_MIN, GenreTaste.count(genres) { it.title } + 2)
            return ordered.filterNot { GenreTaste.isGenre(it.title) } + genres.take(shownGenres)
        }

        /**
         * Shows the kept pictures at once and finds the missing ones, two at a time so they
         * never crowd out a song that is loading. Each arrives on its tile as it is found.
         */
        private suspend fun loadBrowseArt(shown: List<MoodAndGenres.Item>) {
            val (saved, savedAt) = BrowseArt.saved(context)
            browseArt.value = saved
            val missing =
                (listOf(BrowseArt.CHARTS, BrowseArt.NEW_RELEASES) + shown.map { BrowseArt.keyOf(it.endpoint) })
                    .filterNot { it in saved }
            if (missing.isEmpty()) return
            val gate = Semaphore(2)
            coroutineScope {
                missing.forEach { key ->
                    launch {
                        val covers = gate.withPermit { findBrowseArt(key, shown) }
                        if (covers.isNotEmpty()) browseArt.value = browseArt.value + (key to covers)
                    }
                }
            }
            if (browseArt.value.size > saved.size) BrowseArt.save(context, browseArt.value, savedAt)
        }

        /** The first few covers a tile leads to, all from the one page it opens. */
        private suspend fun findBrowseArt(key: String, shown: List<MoodAndGenres.Item>): List<String> {
            val items =
                when (key) {
                    BrowseArt.CHARTS ->
                        YouTube.getChartsPage().getOrNull()?.sections?.flatMap { it.items }
                    BrowseArt.NEW_RELEASES ->
                        YouTube.newReleaseAlbums().getOrNull()
                    else ->
                        shown.firstOrNull { BrowseArt.keyOf(it.endpoint) == key }?.let { mood ->
                            YouTube.browse(mood.endpoint.browseId, mood.endpoint.params).getOrNull()
                                ?.items?.flatMap { it.items }
                        }
                }
            return items.orEmpty().mapNotNull { it.thumbnail }.distinct().take(BrowseArt.COVERS)
        }

        private suspend fun fetchParsedUrlItem(parsedUrl: YouTubeUrlParser.ParsedUrl): YTItem? =
            when (parsedUrl) {
                is YouTubeUrlParser.ParsedUrl.Video -> {
                    // Use next() to get the song details from a video ID
                    YouTube
                        .next(WatchEndpoint(videoId = parsedUrl.id))
                        .getOrNull()
                        ?.items
                        ?.firstOrNull()
                }

                is YouTubeUrlParser.ParsedUrl.Playlist -> {
                    // Fetch playlist details
                    YouTube
                        .playlist(parsedUrl.id)
                        .getOrNull()
                        ?.playlist
                }

                is YouTubeUrlParser.ParsedUrl.Album -> {
                    // For albums, we need to get the browseId from the playlist
                    // First, try to get the album page
                    val albumResult = YouTube.album("MPREb_${parsedUrl.id}")
                    if (albumResult.isSuccess) {
                        albumResult.getOrNull()?.album
                    } else {
                        // If that fails, treat it as a playlist
                        YouTube
                            .playlist(parsedUrl.id)
                            .getOrNull()
                            ?.playlist
                    }
                }

                is YouTubeUrlParser.ParsedUrl.Artist -> {
                    // Fetch artist details
                    if (parsedUrl.id.startsWith("MPRE")) {
                        // It's a browse ID
                        YouTube
                            .artist(parsedUrl.id)
                            .getOrNull()
                            ?.artist
                    } else {
                        // It's a channel ID, we need to find the browse ID
                        // For now, try using the channel ID as browse ID
                        YouTube
                            .artist(parsedUrl.id)
                            .getOrNull()
                            ?.artist
                    }
                }
            }
    }

data class SearchSuggestionViewState(
    val history: List<SearchHistory> = emptyList(),
    val suggestions: List<String> = emptyList(),
    val items: List<YTItem> = emptyList(),
    val parsedUrlItem: YTItem? = null,
    val isUrlQuery: Boolean = false,
)
